package com.example.loginpage;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class SignInActivity extends AppCompatActivity {
    EditText etUsername, etPassword;
    Button btnSignIn;
    int loginAttempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        etUsername = findViewById(R.id.username);
        etPassword = findViewById(R.id.password);
        btnSignIn = findViewById(R.id.signin);

        btnSignIn.setOnClickListener(v -> {
            String enteredUsername = etUsername.getText().toString().trim();
            String enteredPassword = etPassword.getText().toString().trim();

            if (TextUtils.isEmpty(enteredPassword) || TextUtils.isEmpty(enteredPassword)) {
                Toast.makeText(SignInActivity.this, "Username and Password cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            if (enteredUsername.equals(SignUpActivity.savedUsername) && enteredPassword.equals(SignUpActivity.savedPassword)) {
                Toast.makeText(SignInActivity.this, "SignIn Successful!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SignInActivity.this, SuccessActivity.class);
                startActivity(intent);
                finish();
            } else {
                loginAttempts++;
                if (loginAttempts > 2) {
                    btnSignIn.setEnabled(false);
                    Toast.makeText(SignInActivity.this, "Failed login attempts", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SignInActivity.this, "Login Failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
